//please refer to http://playground.arduino.cc/Interfacing/CPPWindows#.UyimLqiSwQ0 for more information
//please refer to http://msdn.microsoft.com/en-us/library/ff802693.aspx for more information
//#include "Serial.h"	// Library header to be included
#include "SerialUtil.h"
#include <iostream>
#include <string>
#include <cv.h>
#include <highgui.h>
#include<Windows.h>
using namespace std;

SerialUtil* su = new SerialUtil();
string str;

IplImage* GetThresholdedImageHSV(IplImage* img)
{
	// Create an HSV format image from image passed  
	IplImage* imgHSV = cvCreateImage(cvGetSize(img), 8, 3);

	cvCvtColor(img, imgHSV, CV_BGR2HSV);

	// Create binary thresholded image acc. to max/min HSV ranges  
	// For detecting blue gloves in "MOV.MPG - HSV mode  
	IplImage* imgThresh = cvCreateImage(cvGetSize(img), 8, 1);

	cvSmooth(imgHSV, imgHSV, 2, 7, 7);

	cvInRangeS(imgHSV,
		cvScalar(0, 0, 50),
		cvScalar(100, 150, 255),

		imgThresh);

	// Tidy up and return thresholded image  
	cvReleaseImage(&imgHSV);
	return imgThresh;
}

int MiddleValue(IplImage* imgThresh)
{
	int x, y, v = 0, c = 0, e = 0, f = 0;
	for (x = 0; x < imgThresh->width; x++)
	{
		v = 0; c = 0;
		for (y = 0; y < imgThresh->height; y++)
		{
			double value = cvGetReal2D(imgThresh, y, x);
			if (value != 0) { v += x; c++; }
		}
		if (c != 0) v /= c;
		//printf("%d\n", v);
		e = e + v;
		if (v != 0) f++;
	}
	if (f != 0) e /= f;
	printf("%d\n", e);
	cvLine(imgThresh, cvPoint(e, 0), cvPoint(e, 480), cvScalar(255, 0, 0), 1, 8, 0);
	return e;
}

int Linetrace(int e)
{
	if (e>480)
	{
		str = 'B';
		su->write(str);
	}
	else if (480 >= e && e>360)
	{
		str = 'b';
		su->write(str);
	}
	else if (360 >= e && e>280)
	{
		str = 'x';
		su->write(str);
	}
	else if (280 >= e && e>160)
	{
		str = 'a';
		su->write(str);
	}
	else if (160 >= e)
	{
		str = 'A';
		su->write(str);
	}
	return 0;
}

int main()
{

	try{

		IplImage* image = 0; //openCV���� ���Ǵ� �ڷ����̴�.
		CvCapture* capture = cvCaptureFromCAM(1); //���� �νĵ� ��ķ�� ã�´�.
		cvResizeWindow("Cam", 640, 480); // ����� �����Ѵ�.(lpIImage�� �Ҵ��ϸ鼭�� ��������)
		
		while (SerialUtil::SP->IsConnected())
		{
			getline(cin, str);
			while (1)
			{
				cvGrabFrame(capture);
				image = cvRetrieveFrame(capture);

				IplImage* imgThresh = GetThresholdedImageHSV(image);
				int e = MiddleValue(imgThresh);

				cvShowImage("OpenCvCamtest1", imgThresh);
				Linetrace(e);
				
				if (cvWaitKey(10) >= 0)
				{
					str = 'X';
					su->write(str);
					break;
				}
			}
			break;
		}
		
		cvReleaseCapture(&capture); // �Ҵ�޾Ҵ� ��ķ�� �����ϰ�,
		cvDestroyWindow("OpenCvCamtest"); // �����츦 �����Ѵ�. 
		
	}
	catch (string s)
	{
		cout << "..ERROR OCCURED::" << s << " :( \n";
	}
	return 0;
}